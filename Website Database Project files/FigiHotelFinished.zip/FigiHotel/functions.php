<?php

//Remove guest
function Remove_guest($first, $last) //DELETE FROM Guest WHERE Guest_first_name = “First” AND Guest_last_name = “Last”;
{
    global $db;
    $sql = "DELETE FROM Guest ";
    $sql .= "WHERE Guest_first_name ='" . $first . "', AND Guest_last_name = '" . $last . "' ";
    $sql .= "LIMIT = 1";

    $result = mysqli_query($db, $sql);

    //Check for true and false
    if($result){
        //can redirect to a guest checkedout page
    } else{
        //DELETE returned false
        echo mysqli_error($db);
        // disconect($db) to be disconect function
        exit; 
    }
}

//Check post
function Check_post(){
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

//find database by key
function data_by_key($table, $primaryKey ,$value){
    global $db;

    $sql = "SELECT * FROM $table ";
    $sql = "WHERE '" . $primaryKey . "' ='" . $value . "'";

    $result = mysqli_query($db, $sql);
    check_result_set($result);

    $subject = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $subject; //assosiative array that is the values of the row with collumn name as their index
}

//these 2 functions created by Kevin Skoglund in PHP with MySQL Essential Training on linkdin learning
//page redirect
function redirect_to($location) {
    header("Location: " . $location);
    exit;
  }

//format to url
function url_for($script_path) {
  // add the leading '/' if not present
  if($script_path[0] != '/') {
    $script_path = "/" . $script_path;
  }
  return $script_path;
}

//Functions written by ""
function new_Guest($first, $last, $lengthStay, $checkedIn, $inDate, $outDate, $points, $roomNum, $phone) {
  global $db;
  $sql = "INSERT INTO guest VALUES('".$first."', '".$last."', '".$lengthStay."', '".$checkedIn."', '".$inDate."', '".$outDate."', '".$points."', '".$roomNum."', '".$phone."')";

  $result = mysqli_query($db, $sql);
    echo $result;
  if($result){
      echo "success";
  }else{
      echo mysqli_error($db);
  }
}


function update_Ledger($inTime, $outTime, $first, $last, $phone, $inDate, $outDate, $roomNum){
  global $db;
  $sql = "INSERT INTO ledger VALUES('".$inTime."', '".$outTime."', '".$first."', '".$last."', '".$phone."', '".$inDate."', '".$outDate."', '".$roomNum."')";

  $result = mysqli_query($db, $sql);

  if($result){
      echo "success";
  }else{
      echo mysqli_error($db);
  }
}

//Functions Written by Colin
function last_Housekeeping_Time ($room_number){
  global $db;

  $sql = "SELECT Housekeeping_last_time FROM Room";
  $sql .= "WHERE Room_number ='" . $room_number . "'";
  $result = mysqli_query($db, $sql);

  if($result){
      echo "success";
  } else{
      echo mysqli_error($db);
  }
}

//View of all rooms (and their types) in use by customers
function all_Room_View(){
  global $db;

  $sql = "SELECT COUNT(Room_type) FROM Room";
  $sql .= "WHERE Available = '" . false . "'";
  $sql .= "GROUP BY Room_type";

  $result = mysqli_query($db, $sql);

  if($result){
      echo "success";
  } else{
      echo mysqli_error($db);
  }
}


/*
function  guest_points($Guest_firstname, $Guest_lastname,$Room_num)
{
  global $db;
  
    $sql = "UPDATE Guest";
    $sql = "SET Guest.Points_balance = " . "Guest.Points_balance" - Room.Points_room;
    $sql .= "From Guest";
    //join
    $sql .= "INNER JOIN Room ON Guest.Room_number = Room.Room_number";
    //looks for name
    $sql .= "WHERE '" . Guest_first_name . "' = Guest.Guest_firstname AND '"  . Guest_last_name . "'= Guest_lastname;";
    //return remaining points balance
    $result = mysqli_query($db, $sql);
}
*/


function Log_emp($EMP_ID, $clock_in, $clock_out)
{
    global $db;
    $sql = "UPDATE `employee` SET `Start_time`='" . $clock_in . "',`End_time`= '" . $clock_out . "' WHERE employee.Employee_ID_number = '" . $EMP_ID . "';";

    $result = mysqli_query($db, $sql);

    if($result)
    {
        echo "success";
    }else{
        echo mysqli_error($db);
        exit;
    }
}

?>