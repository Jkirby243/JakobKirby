<!doctype html> 
<html lang = "en">
<html>
    <head>
        <link rel="stylesheet" href="home.css">
    </head>
    <body>
        <div>
            <h1 class="title">Figi Waters Resort</h1>
            <table class="menu-bar">
                <tr>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/home.php">Home</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/rates.php">Rates</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/booking.php">Booking</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/employee.php">Employee</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/account.php">Account</a></button></th>
                </tr>
            </table>
        </div>

        <h3 class="page-title">Clock In / Clock Out</h3>
        
        <form action="<?php echo url_for('/FigiHotel/Clockin.php') ?>" method="post">
            <p>Clock In Time: </p>
            <input class="clock" type="text" id="clock-in" name="clock-in" value="">
            <p>Clock Out Time: </p>
            <input class="clock" type="text" id="clock-out" name="clock-out" value="">
            <p>12 Digit ID: </p>
            <input class="clock" type="text" id="emp_ID" name="emp_ID" value="">

            <button class="next-button" type="submit" href="/FigiHotel/Clockin.php">Submit</button>
        </form>
    </body>
</html>