<?php

require('functions.php');
require('databasefunctions.php');
require('sqlInject_functions.php');
$db = database_connect();
if(mysqli_connect_errno()){
    $msg = $mysqli_connect_error();
    exit($msg);
}
$room = 100;
?>