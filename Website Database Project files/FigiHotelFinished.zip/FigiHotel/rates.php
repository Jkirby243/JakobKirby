<html>
    <head>
        <link rel="stylesheet" href="home.css">
    </head>
    <body>
        <div>
            <h1 class="title">Figi Hotel</h1>
            <table class="menu-bar">
                <tr>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/home.php">Home</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/rates.php">Rates</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/booking.php">Booking</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/employee.php">Employee</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/account.php">Account</a></button></th>
                </tr>
            </table>
        </div>

        <h2 class="page-title">Room Rates</h2>
        <hr class="page-title-separator">

        <h3 class="section-name">One Bed Rooms</h3>
            <hr class="section-separator" />
            <p class="room-name">Lake Room</p>
                <p class="room-description">Enjoy your stay in our Lake Room, complete with a faucet that brings the lake water to you!</p>
                <img src="img/Lake.jpg" alt="Lake Picture">
                <p>One Queen Bed, One Bathroom</p>
                <p>Price: $60 per night</p>
            <hr class="room-separator" />
            <p class="room-name">Pond Room</p>
                <p class="room-description">Swim with tadpoles in our Pond Room, featuring a pond instead of a bathtub!</p>
                <img src="img/Pond.jpg" alt="Pond Picture">
                <p>One King Bed, One Bathroom</p>
                <p>Price: $80 per night</p>

        <h3 class="section-name">Two Bed Rooms</h3>
            <hr class="section-separator" />
            <p class="room-name">River Room</p>
                <p class="room-description">Immerse yourself in a babbling brook in our River Room, with speakers that play river noises 24/7!</p>
                <img src="img/River.jpg" alt="River Picture">
                <p>Two Queen Beds, One Bathroom</p>
                <p>Price: $100 per night</p>
            <hr class="room-separator" />
            <p class="room-name">Ocean Room</p>
                <p class="room-description">Grab your life jacket in our Ocean Room, where crashing waves will surprise you at any point!</p>
                <img src="img/Ocean.jpg" alt="Ocean Picture">
                <p>One Queen Bed, One King Bed, One Bathroom</p>
                <p>Price: $130 per night</p>

        <h3 class="section-name">Suites</h3>
            <hr class="section-separator" />
            <p class="room-name">Seven Seas Suite</p>
                <p class="room-description">Sail the seven seas in our Seven Seas Suite, by trying seafood from the Dead Sea!</p>
                <img src="img/SevenSeas.jpg" alt="Dead Sea Picture">
                <p>4 Queen Beds, 2 Bathrooms, Jacuzzi Tub</p>
                <p>Price: $200 per night</p>
    </body>
</html>