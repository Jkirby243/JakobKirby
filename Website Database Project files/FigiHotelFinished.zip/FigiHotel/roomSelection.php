<html>
    <head>
        <link rel="stylesheet" href="home.css">
    </head>
    <body>
        <div>
            <h1 class="title">Figi Waters Resort</h1>
            <table class="menu-bar">
                <tr>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/home.php">Home</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/rates.php">Rates</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/booking.php">Booking</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/employee.php">Employee</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/account.php">Account</a></button></th>
                </tr>
            </table>
        </div>

        <h2 class="page-title">Room Selection</h2>
        <hr class="page-title-separator" />

        <?php include("functions.php"); ?>
        <form action="<?php echo url_for('/FigiHotel/New_guest.php') ?>" method="POST">
            <input class="room-selection" type="checkbox" id="lake" name="lake" value="100">
            <label class="room-selection-text" for="lake"> Reserve Lake Room</label><br>
            
            <input class="room-selection" type="checkbox" id="pond" name="pond" value="200">
             <label class="room-selection-text" for="pond"> Reserve Pond Room</label><br>

            <input class="room-selection" type="checkbox" id="river" name="river" value="300">
            <label class="room-selection-text" for="river"> Reserve River Room</label><br>

            <input class="room-selection" type="checkbox" id="ocean" name="ocean" value="450">
           <label class="room-selection-text" for="ocean"> Reserve Ocean Room</label><br>

            <input class="room-selection" type="checkbox" id="suite" name="suite" value="600">
            <label class="room-selection-text" for="suite"> Reserve Seven Seas Suite</label><br>
        </form>


        <p></p>
       
        <button class="confirm-button" type="submit" href="/FigiHotel/roomSuccess.php"> Confirm Your Stay</button>

    </body>
</html>