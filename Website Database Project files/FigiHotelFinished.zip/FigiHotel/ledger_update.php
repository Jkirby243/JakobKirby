<?php
//Got this redirect pages format from Kevin Skoglund in PHP with MySQL Essential Training on linkdin learning
if(Check_post()){

    $in_Time = $_POST['Check_in_time'];
    $Check_out_time = $_POST['Check_out_time'];
    $Guest_first_name = $_POST['Guest_first_name'];
    $Guest_last_name = $_POST['Guest_last_name'];
    $Guest_phone_number = $_POST['Guest_phone_number'];
    $Check_in_date = $_POST['Check_in_date'];
    $Check_out_date = $_POST['Check_out_date'];
    $Room_number = $_POST['Room_number'];
    
    update_Ledger($inTime, $Check_out_time, $Guest_first_name, $Guest_last_name, $Guest_phone_number, $inDate, $outDate, $Room_number); //ledger update function being passed the row just added in new guest

    redirect_to(url_for('Figi/home.php'));
}else{
    redirect_to(url_for('employee.php'));
}

?>