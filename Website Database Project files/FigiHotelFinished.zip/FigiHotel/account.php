<html>
    <head>
        <link rel="stylesheet" href="home.css">
    </head>
    <body>
        <div>
            <h1 class="title">Figi Waters Resort</h1>
            <table class="menu-bar">
                <tr>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/home.php">Home</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/rates.php">Rates</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/booking.php">Booking</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/employee.php">Employee</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/account.php">Account</a></button></th>
                </tr>
            </table>
        </div>

        <h2 class="page-title">Account</h2>
        <hr class="page-title-separator" />

        <p>First Name: </p>
        <p>Last Name: </p>
        <p>Phone Number: </p>
        <p>Current Bookings: </p>
       
        <button class="confirm-button" type="button"><a href="/FigiHotel/logoutSuccess.php">Logout</a></button>
    </body>
</html>