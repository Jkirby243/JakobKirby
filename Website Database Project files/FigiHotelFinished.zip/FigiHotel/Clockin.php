<?php

require_once('initialize.php');
if(isset($_POST)){

    $clockIn = $_POST['clock-in'];
    $clockOut = $_POST['clock-out'];
    $ID = $_POST['emp_ID'];

    $result = Log_emp($ID,$clockIn,$clockOut);

     //Redirect
     redirect_to(url_for("FigiHotel/clockSuccess.php"));
    }else{
    //REDIRECT back
    redirect_to(url_for('FigiHotel/employee.php'));


}

?>