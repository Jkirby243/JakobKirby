<html>
    <head>
        <link rel="stylesheet" href="home.css">
    </head>
    <body>
        <div>
            <h1 class="title">Figi Waters Resort</h1>
            <table class="menu-bar">
                <tr>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/home.php">Home</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/rates.php">Rates</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/booking.php">Booking</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/employee.php">Employee</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/account.php">Account</a></button></th>
                </tr>
            </table>
        </div>

        <h2 class="page-title">Room Confirmation</h2>
        <hr class="page-title-separator" />
        <?php require_once('initialize.php') ?>
        <p class="section-name">Congratulations! You have successfully booked your stay. We look forward to seeing you!</p>
        <?php
            //$id = $_GET['id'];
            //$roomRecord = mysqli_query($db, "select check_in_date, check_out_date, room_number from guest where'".  $id . "'= (Select '" . $id . "' from guest)");
            //while($data[] = mysqli_fetch_array($roomRecord)) {
                ?>
                <p>Check In Date: <?php echo $_GET['stayStart'];?></p>
                <p>Check Out Date: <?php echo $_GET['outDate'];?></p>
                <p>Room Number: <?php echo $_GET['roomNumber'];?></p>
            <?php
            //}
            ?>
            <?php mysqli_close($db) ?>
        <p></p>
        <button class="confirm-button" type="button"><a href="/FigiHotel/home.php">Return Home</a></button>

    </body>
</html>