<?php
    //Code created by Kevin Skoglund in PHP with MySQL Essential Training on linkdin learning
    function database_connect()
    {
        $connect = mysqli_connect("localhost", "root", "","figi");//YOU WILL NEED YOUR OWN USERNAME AND PASSWORD AS WELL AS YOUR HOST AND DATABASE
        return $connect;
    }

    function database_disconnect($connection)
    {
        mysqli_close($connection);
    }
    
    function check_result_set($result_set){ //Need to see if a result set was returned 
        if(!$result_set){
            exit("Database query failed.");
        }
    }

    
?>