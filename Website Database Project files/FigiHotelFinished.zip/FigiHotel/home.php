<html>
    <head>
        <link rel="stylesheet" href="home.css">
    </head>
    <body>
        <div>
            <h1 class="title">Figi Waters Resort</h1>
            <table class="menu-bar">
                <tr>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/home.php">Home</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/rates.php">Rates</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/booking.php">Booking</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/employee.php">Employee</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/account.php">Account</a></button></th>
                </tr>
            </table>
        </div>

        <img class="logo" src="img/figiwaters.png">
        <div class="hotel-description">
            <h1>About Us</h1>
            <p>
                We pride ourselves on being open to anyone, while still being affordable so that you can have a 
                luxury experience without compromising your wallet. 
            </p>
            <p>We offer the largest rooms on the market!</p>
            <p>Fun Fact: We are the preferred hotel option of Micheal Phelps, the Olympic gold medalist!</p>
            <p>Click on the top bar to naviate to our room rates or booking page!</p>
        </div>
    </body>
</html>
