 
<?php

require_once('initialize.php');
//Got this redirect idea from Kevin Skoglund in PHP with MySQL Essential Training on linkdin learning
if(isset($_POST)){
        global $room;
        print_r( $_POST);
    $Guest_first_name = $_POST["first-name"];
    $Guest_last_name = $_POST["last-name"];
    $Length_of_stay = $_POST["length-of-stay"];
    $Check_in_date = $_POST["stay-start"];
    $Check_out_date = $_POST["stay-end"];
    $Guest_phone_number = $_POST["phone-1"] . $_POST["phone-2"] . $_POST["phone-3"];
    $Room_number = $room;
    $room = $room + 1;
    $points = $_POST["lake"] + $_POST["pond"] + $_POST["river"] + $_POST["ocean"] + $_POST['suite'];

    $result = new_guest($Guest_first_name, $Guest_last_name, $Length_of_stay, false ,$Check_in_date, $Check_out_date, $points ,$Room_number ,$Guest_phone_number);
    
    //Redirect
        redirect_to(url_for("FigiHotel/roomSuccess.php?stayStart=" . $Check_in_date . "&outDate=" .  $Check_out_date . "&roomNumber=" . $Room_number));
        }else{
        //REDIRECT back
        redirect_to(url_for('FigiHotel/booking.php'));
    
} 

?>