
<!doctype html>
<html>
    <head>
        <link rel="stylesheet" href="home.css">
    </head>
    <body>
        <div>
            <h1 class="title">Figi Waters Resort</h1>
            <table class="menu-bar">
                <tr>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/home.php">Home</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/rates.php">Rates</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/booking.php">Booking</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/employee.php">Employee</a></button></th>
                    <th><button type="button" class="menu-button"><a href="/FigiHotel/account.php">Account</a></button></th>
                </tr>
            </table>
        </div>

        <h2 class="page-title">Booking</h2>
        <hr class="page-title-separator" />
        <?php include("functions.php"); ?>
        <form action="<?php echo url_for('/FigiHotel/New_guest.php') ?>" method="post">
            <p>First Name:</p>
            <input class="booking-form" name="first-name" type="text" value = "">
            <p>Last Name:</p>
            <input class="booking-form" name="last-name" type="text" value = "">
            <p>Length of Stay:</p>
            <input class="booking-form" name="length-of-stay" type="text" value = "">
            <p>Check In Date:</p>
            <input type="date" value="2021-1-1" name="stay-start" min="2021-1-1" max="2023-1-1">
            <p>Check Out Date:</p>
            <input type="date" value="2021-1-1" name="stay-end" min="2021-1-1" max="2023-1-1">
            <p>Phone Number:</p>
            <th>
                <input class="booking-form-phone" name="phone-1" type="text" value = "">
                <input class="booking-form-phone" name="phone-2" type="text" value = "">
                <input class="booking-form-phone" name="phone-3" type="text" value = "">
            </th>
            <input class="room-selection" type="checkbox" id="lake" name="lake" value="100">
            <label class="room-selection-text" for="lake"> Reserve Lake Room</label><br>
            
            <input class="room-selection" type="checkbox" id="pond" name="pond" value="200">
             <label class="room-selection-text" for="pond"> Reserve Pond Room</label><br>

            <input class="room-selection" type="checkbox" id="river" name="river" value="300">
            <label class="room-selection-text" for="river"> Reserve River Room</label><br>

            <input class="room-selection" type="checkbox" id="ocean" name="ocean" value="450">
           <label class="room-selection-text" for="ocean"> Reserve Ocean Room</label><br>

            <input class="room-selection" type="checkbox" id="suite" name="suite" value="600">
            <label class="room-selection-text" for="suite"> Reserve Seven Seas Suite</label><br>

                    
            <p></p>
            <button class="next-button" type="submit" value = "submit" href="/FigiHotel/New_guest.php">Next</button>
        </form>


    </body>
</html>