<?php
//These are all just short versions of functions to just call other functions

//THIS FUNCTION WILL PASS THE SQL INTO OUR DATABASE WITH /'s AROUND ANY '
function escape($db, $data){
    return mysqli_escape_string($db,$data);
}

//OTHER THAN THIS FOR DATA THAT A ATTACKER MIGHT ENTER PUT ' AROUND ALL VALUES SO SQL READ THE VARIABLE AS A STRING AND WILL JUST HAVE TO DO A LITTLE BIT OF THINKING
?>